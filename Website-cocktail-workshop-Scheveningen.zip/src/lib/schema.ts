import { extras, faqs, googleSameAs, prices, site } from "@/lib/site";
import { reviews } from "@/lib/reviews";

export function jsonLdGraph() {
  const logoUrl = `${site.url}${site.logoPath}`;
  const imageUrl = `${site.url}/images/cocktail-shaker.jpg`;
  const postalAddress = {
    "@type": "PostalAddress",
    name: "Kantoor",
    streetAddress: site.address.streetAddress,
    postalCode: site.address.postalCode,
    addressLocality: site.address.addressLocality,
    addressRegion: site.address.addressRegion,
    addressCountry: site.address.addressCountry,
  };

  return {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": `${site.url}/#organization`,
        name: site.legalName,
        url: site.url,
        logo: {
          "@type": "ImageObject",
          url: logoUrl,
        },
        image: imageUrl,
        email: site.email,
        telephone: site.phoneInternational,
        sameAs: googleSameAs(),
        address: postalAddress,
      },
      {
        "@type": "WebSite",
        "@id": `${site.url}/#website`,
        url: site.url,
        name: site.name,
        inLanguage: "nl-NL",
        description: site.description,
        publisher: { "@id": `${site.url}/#organization` },
      },
      {
        "@type": "WebPage",
        "@id": `${site.url}/#webpage`,
        url: `${site.url}/`,
        name: "Cocktail Workshop Scheveningen | Boek jouw bartender workshop aan zee",
        isPartOf: { "@id": `${site.url}/#website` },
        about: { "@id": `${site.url}/#service` },
        description: site.description,
        inLanguage: "nl-NL",
        dateModified: new Date().toISOString().slice(0, 10),
        primaryImageOfPage: {
          "@type": "ImageObject",
          url: imageUrl,
        },
        speakable: {
          "@type": "SpeakableSpecification",
          cssSelector: ["h1", "#workshop h2", "#faq"],
        },
        breadcrumb: { "@id": `${site.url}/#breadcrumb` },
      },
      {
        "@type": ["LocalBusiness", "ProfessionalService"],
        "@id": `${site.url}/#business`,
        name: site.legalName,
        url: site.url,
        email: site.email,
        telephone: site.phoneInternational,
        image: [imageUrl, logoUrl],
        logo: logoUrl,
        description: site.description,
        parentOrganization: { "@id": `${site.url}/#organization` },
        priceRange: "€€",
        currenciesAccepted: "EUR",
        paymentAccepted: "Bankoverschrijving, iDEAL",
        hasMap: site.mapsUrl,
        sameAs: googleSameAs(),
        knowsAbout: [
          "Cocktail workshop Scheveningen",
          "Bartender workshop",
          "Vrijgezellenfeest Scheveningen",
          "Bedrijfsuitje Scheveningen",
        ],
        contactPoint: {
          "@type": "ContactPoint",
          telephone: site.phoneInternational,
          email: site.email,
          contactType: "reservations",
          areaServed: "NL",
          availableLanguage: ["nl", "Dutch"],
        },
        ...(reviews.length > 0
          ? {
              aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: (
                  reviews.reduce((sum, review) => sum + review.rating, 0) /
                  reviews.length
                ).toFixed(1),
                reviewCount: reviews.length,
                bestRating: 5,
                worstRating: 1,
              },
              review: reviews.map((review) => ({
                "@type": "Review",
                author: { "@type": "Person", name: review.author },
                datePublished: review.datePublished,
                reviewBody: review.text,
                reviewRating: {
                  "@type": "Rating",
                  ratingValue: review.rating,
                  bestRating: 5,
                  worstRating: 1,
                },
              })),
            }
          : {}),
        areaServed: [
          ...site.citiesServed.map((name) => ({
            "@type": "City",
            name,
          })),
          {
            "@type": "Country",
            name: "Nederland",
            identifier: site.countryServed,
          },
        ],
        address: postalAddress,
        geo: {
          "@type": "GeoCoordinates",
          latitude: site.geo.latitude,
          longitude: site.geo.longitude,
        },
        hasOfferCatalog: {
          "@type": "OfferCatalog",
          name: "Cocktail workshops Scheveningen",
          itemListElement: [
            ...prices.map((item) => ({
              "@type": "Offer",
              name: `Cocktail workshop Scheveningen ${item.label}`,
              priceCurrency: "EUR",
              price: item.price.replace("€ ", "").replace(",", "."),
              availability: "https://schema.org/InStock",
            })),
            ...extras.map((item) => ({
              "@type": "Offer",
              name: item.label,
              priceCurrency: "EUR",
              price: item.price.replace("€ ", "").replace(",", "."),
              availability: "https://schema.org/InStock",
            })),
          ],
        },
      },
      {
        "@type": "Service",
        "@id": `${site.url}/#service`,
        name: "Cocktail workshop Scheveningen",
        serviceType: "Cocktail workshop op locatie",
        description:
          "Cocktail workshops bij strandtenten en restaurants in Scheveningen. Kantoor op Schokkerweg 38.",
        provider: { "@id": `${site.url}/#business` },
        areaServed: {
          "@type": "AdministrativeArea",
          name: "Scheveningen, Den Haag, Zuid-Holland",
        },
        offers: {
          "@type": "AggregateOffer",
          priceCurrency: "EUR",
          lowPrice: 30,
          highPrice: 37.5,
          offerCount: prices.length,
        },
      },
      {
        "@type": "FAQPage",
        "@id": `${site.url}/#faq`,
        mainEntity: faqs.map((faq) => ({
          "@type": "Question",
          name: faq.question,
          acceptedAnswer: {
            "@type": "Answer",
            text: faq.answer,
          },
        })),
      },
      {
        "@type": "BreadcrumbList",
        "@id": `${site.url}/#breadcrumb`,
        itemListElement: [
          {
            "@type": "ListItem",
            position: 1,
            name: "Home",
            item: `${site.url}/`,
          },
          {
            "@type": "ListItem",
            position: 2,
            name: "Cocktail Workshop Scheveningen",
            item: `${site.url}/#workshop`,
          },
        ],
      },
    ],
  };
}
